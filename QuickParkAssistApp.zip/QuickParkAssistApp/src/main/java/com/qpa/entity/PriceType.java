package com.qpa.entity;

public enum PriceType {
	HOURLY,
	DAILY
}
