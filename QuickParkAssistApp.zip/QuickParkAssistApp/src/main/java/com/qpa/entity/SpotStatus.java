package com.qpa.entity;

public enum SpotStatus {
	AVAILABLE,
	UNAVAILABLE
}
