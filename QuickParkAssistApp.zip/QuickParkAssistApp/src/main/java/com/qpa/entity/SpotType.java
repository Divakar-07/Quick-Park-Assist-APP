package com.qpa.entity;

public enum SpotType {
	COVERED,
	UNCOVERED,
	UNDERGROUND
}
