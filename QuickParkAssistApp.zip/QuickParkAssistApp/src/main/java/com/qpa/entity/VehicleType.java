package com.qpa.entity;

public enum VehicleType {
    CAR,
    TRUCK,
    MOTORCYCLE,
    BUS,
    VAN,
    SUV,
    PICKUP,
    ELECTRIC_CAR,
    HYBRID_CAR
}