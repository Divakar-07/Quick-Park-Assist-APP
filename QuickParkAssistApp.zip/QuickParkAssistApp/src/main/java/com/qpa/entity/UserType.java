package com.qpa.entity;

public enum UserType {
    VEHICLE_OWNER, SLOT_OWNER
}
